# Ainak_App_for_visually_impaired_people

*Project status : ongoing 

**Preffered Tech Stack** : Flutter | C++ | FlutterFlow |

**Contributors** : [Dr. Mayank Aggarwal](https://scholar.google.co.in/citations?user=BZMlWLwAAAAJ&hl=en) | [Chirag Patel](https://github.com/colonel-chirag) | [Divyank Singh](https://github.com/divyanksingh-git) | [Ashish Bibyan](https://github.com/ABS-007) 

Project Consequences :  App | Research Paper |

Project Deadline : November 2022

*Project Chronology* -: 

Project Mentor  [Dr. Mayank Aggarwal](https://scholar.google.co.in/citations?user=BZMlWLwAAAAJ&hl=en) 

Project Manager [Chirag Patel](https://github.com/colonel-chirag) 

Front - End [Chirag Patel](https://github.com/colonel-chirag) | [Ashish Bibyan](https://github.com/ABS-007)  

Back - End [Chirag Patel](https://github.com/colonel-chirag) | [Divyank Singh](https://github.com/divyanksingh-git) 

Testing / Deployment [Divyank Singh](https://github.com/divyanksingh-git) | [Ashish Bibyan](https://github.com/ABS-007) 

Privacy Policy [Chirag Patel](https://github.com/colonel-chirag)

Project Report / Presentation [Ashish Bibyan](https://github.com/ABS-007) | [Ankit Bansal](https://github.com/theankitbansal) |
